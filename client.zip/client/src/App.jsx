
import './App.css'
import Routing from './Layout/Routing'


function App() {
 
  return (
    <>
      <Routing/>
    </>
  )
}

export default App
