import ShowPage from "../components/ShowPage";
import { BrowserRouter as Router, Routes, Route, Outlet } from 'react-router-dom';
import { useState } from 'react';
import { io } from 'socket.io-client'
import { SocketContext } from "../context/SocketContext";

const Routing = () => {
    const [socket, setSocket] = useState(io('http://localhost:3000'));

    return ( 
    <div>

         <SocketContext.Provider value={{ socket, setSocket }}>
            <Routes>
                <Route path='/' element={<ShowPage  />} />
            </Routes>
        </SocketContext.Provider>
        
    </div> );
}
 
export default Routing;