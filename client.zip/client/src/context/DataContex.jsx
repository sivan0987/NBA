import { createContext, useContext } from 'react'

export const DataContext = createContext({})

const usePage = () => useContext(DataContext)

export default usePage;