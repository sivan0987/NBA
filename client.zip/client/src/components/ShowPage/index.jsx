
import { useEffect, useState } from 'react';
import useSocket from '../../context/SocketContext';

const ShowPage = () => {

    const { socket } = useSocket();
    const [showPopUp, setShowPopUp] = useState(false)
    socket.on("hi", () => {
        setShowPopUp(true);
        console.log("we got you");
    });
    useEffect(() => {
        if (showPopUp) {
            const timer = setTimeout(() => {
                setShowPopUp(false);
            }, 3000);

           
            return () => clearTimeout(timer);
        }
    }, [showPopUp]);

    return (<div>
    {showPopUp && <h1>players change</h1> }


    </div>);
}

export default ShowPage;