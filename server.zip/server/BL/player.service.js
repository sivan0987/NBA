
const fs = require('fs');
const Papa = require('papaparse');
const apiKey = 'd66cf8cf-e004-4fde-93fd-6ec0712bad9c';
function readCSV(filePath) {
    return new Promise((resolve, reject) => {
        const file = fs.readFileSync(filePath, 'utf8');

        Papa.parse(file, {
            header: true,
            complete: function (results) {
                resolve(results.data);
            },
            error: function (error) {
                reject(error);
            }
        });
    });
}
async function getAllPlayersData(filePath){
    const res =await fetch(filePath, {
        headers: {
            'Authorization': `${apiKey}` // 
        }
    });
    if (!res.ok){
        throw new Error('Network response was not ok')
    }
    const data = await res.json()
    return data;
}
 function writeTocsv(csvplayerData,playersData) {

    const arrans = [];
    csvplayerData.forEach(player => {
    const p = playersData["data"].find(x => x.id === Number(player.id));
        if (p){
            const temp = {...p, ...p.team }
            delete p.team;
            arrans.push(temp)
        }
    });
    const csvFile =  Papa.unparse(arrans);
    // console.log("ans",ans);
    
    return {arrans , csvFile} ;
}

async function fetchPlayerData(filePath) {
    const response = await fetch(filePath);
    // console.log("response",response);
    
    if (!response.ok) {
        throw new Error('Network response was not ok');
    }
    const data = await response.json();
    return data; 
    
}
async function getLastUpdat() {
    const lastUpdata = await fetchPlayerData('http://localhost:3000/player');
    return lastUpdata;
}
module.exports = {readCSV,getAllPlayersData,writeTocsv ,fetchPlayerData,getLastUpdat};