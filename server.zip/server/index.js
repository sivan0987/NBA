const express = 
  require("express"),
  app = express(),
  PORT = 3000,
  cors = require("cors"),
  http = require("http"),
  server = http.createServer(app),
  socketIO = require("socket.io");
 
 const io = new socketIO.Server(server, {
  cors: {
    origin: "*",
  },
});
require('./socket.js')(io)
app.use(cors());
app.use(express.json());

const playersRouter = require("./router/player.router")
app.use("/",playersRouter);

const db = require('./db.js')
const cheackChanges = require('./cheackChanges.js')
 
db.connect();
server.listen(PORT, () => console.log("##### Server is UP #####"));