


module.exports = (io) => {
    ioInstance = io; // Store the io instance
    io.on("connection", (socket) => {
        console.log("Socket connected:", socket.id);

        socket.on("hi", () => {
            console.log("Received 'hi' event");
        });

        socket.on("disconnect", () => {
            console.log("Socket disconnected:", socket.id);
        });
    });
};
module.exports.getIo = () => ioInstance;