const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('mydatabase.js');
const playerService = require('./BL/player.service.js');


async function createTable() {
    return new Promise((resolve, reject) => {
        db.run(`CREATE TABLE IF NOT EXISTS players (
            id INTEGER PRIMARY KEY,
            first_name TEXT,
            last_name TEXT,
            position TEXT,
            height TEXT,
            weight TEXT,
            jersey_number TEXT,
            college TEXT,
            country TEXT,
            draft_year INTEGER,
            draft_round INTEGER,
            draft_number INTEGER,
            team TEXT
        )`, (err) => {
            if (err) {
                reject(err);
            } else {
                resolve();
            }
        });
    });
}

async function insertPlayers(players) {
    // console.log("playerssssssssss",players);
    
    return new Promise((resolve, reject) => {
        const stmt = db.prepare(`INSERT OR REPLACE INTO players 
            (id, first_name, last_name, position, height, weight, jersey_number, college, country, draft_year, draft_round, draft_number, team) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
        
        players.forEach(player => {
            stmt.run(
                player.id,
                player.first_name || '',
                player.last_name || '',
                player.position || '',
                player.height || '',
                player.weight || '',
                player.jersey_number || '',
                player.college || '',
                player.country || '',
                player.draft_year || null,
                player.draft_round || null,
                player.draft_number || null,
                player.team || ''
            );
        });

        stmt.finalize((err) => {
            if (err) {
                reject(err);
            } else {
                resolve();
            }
        });
    });
}

async function connect() {
    try {
        await createTable(); 
        // give the current players with full data and insert them to the table
        const players = await playerService.fetchPlayerData('http://localhost:3000/player');
        await insertPlayers(players);
        console.log('Players data inserted successfully.');
    } catch (error) {
        console.error('Error:', error);
    } 
}
module.exports = {connect, insertPlayers };
