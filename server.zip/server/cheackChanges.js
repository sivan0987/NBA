const playerService = require('./BL/player.service');
const { getIo } = require('./socket.js');
const db = require('./db.js')
let lastUpdate = playerService.getLastUpdat()

async function cheackChanges() {
    try {
        console.log("Fetching player data...");
        const players = await playerService.fetchPlayerData('http://localhost:3000/player');
        console.log("Players data fetched:", players);

        console.log("Last Update:", lastUpdate);
        let isEqual = JSON.stringify(players) === JSON.stringify(lastUpdate);
        console.log("isEqual:", isEqual);  

        if (!isEqual) {
            console.log("Data has changed, updating lastUpdate.");
            lastUpdate = players;
            await db.insertPlayers(players);
            console.log('Players data updated successfully.');

            const io = getIo();
            if (io) {
                console.log("Emitting 'hi' event.");
                io.emit('hi');
            }
        } else {
            console.log("Data is the same, no changes made.");
        }

    } catch (err) {
        console.error('Error:', err);
    }
}

setInterval(cheackChanges, 4000);

module.exports = { cheackChanges };