const express = require("express"),
    router = express.Router(),
    fs = require('fs'),
    playerService = require('../BL/player.service');

router.get('/player', async (req, res) => {
    try {
        const csvplayerData = await playerService.readCSV('C://Users//USER//Desktop//NBA//server//router//players.csv');
        const playersData = await playerService.getAllPlayersData('https://api.balldontlie.io/v1/players')
        const {arrans ,csvFile} = playerService.writeTocsv(csvplayerData,playersData)
        fs.writeFileSync('output.csv', csvFile);
        console.log('CSV file has been created successfully.');
        res.send(arrans);

    } catch (error) {
        console.error("Error:", error);
        res.status(500).send(error);
    }
});

module.exports = router;
